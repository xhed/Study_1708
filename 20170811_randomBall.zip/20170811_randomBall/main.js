// var Ball = document.getElementById('Ball');
var containerWidth = 800;
var containerHeight = 600;

/**
 * 通过恒定速度，和随机的运动方向，计算出来随机的x轴和y轴随机速度
 * @param {number} v 像各个方向运动时的恒定速度
 */
var randomV = function(v){
    var randomAngle = (Math.PI * 2)*Math.random();
    var vy = v*Math.sin(randomAngle);
    var vx = v*Math.cos(randomAngle);
    return {
        x:vx,
        y:vy
    }
}

var n = 0;
var v = randomV(5);
var randomMove = setInterval(function(){

    if(n>=100){
        var v = randomV(5);
        n=0;
    }
    Ball.style.top = parseInt(Ball.style.top) + v["y"] + "px";
    Ball.style.left = parseInt(Ball.style.left) + v["x"] + "px";

    n++;
},100)

// console.log(Math.sin(0.25*Math.PI),Math.cos(0.25*Math.PI));
// console.log(Math.sin(0.75*Math.PI),Math.cos(0.75*Math.PI));


// console.log(Math.sin(1.25*Math.PI),Math.cos(1.25*Math.PI));
// console.log(Math.sin(1.75*Math.PI),Math.cos(1.75*Math.PI));